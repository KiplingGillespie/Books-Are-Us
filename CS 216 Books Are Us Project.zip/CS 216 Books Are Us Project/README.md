# Books-R-Us

Code Standards.
Capitalize Method names. 
Don't Capitalize data members.
